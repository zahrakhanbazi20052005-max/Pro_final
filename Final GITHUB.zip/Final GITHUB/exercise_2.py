"تکه برنامه ای بنویسید که دارای تابع پیچیدگی زمانی زیر باشد"
F(n) = 3n**2 + 4n-8 ____ 4(n-2)
    for i in range(n):
        for i in range(n):
            print(i)
            print(j)
            print(i+j)
    for i in range(n-2)
        a=b 
        b=c 
        c=d 
        d=e



#for i in range(n):
#    for i in range(n):
#        p=k 
#    t=s 

#F(n) = n**2 + n        

# n**2 به معنای (n) به توان دو
