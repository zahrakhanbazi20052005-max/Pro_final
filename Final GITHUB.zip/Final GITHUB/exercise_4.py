"فرمول"
for i in range(start,stop,step):
    k = ...

F(n) = k/step (stop - start)



"تمرین"
for i in range(10,2*n+6,5):
    p=k 
    k=s 
    j=l 

F(n) = 3/5(2 n-4) = 1.2 n - 2.4
